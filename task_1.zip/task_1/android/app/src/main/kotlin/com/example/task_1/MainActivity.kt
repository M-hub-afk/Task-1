package com.example.task_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

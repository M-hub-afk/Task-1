import 'package:flutter/material.dart';
import '../models/flashcard.dart';

class AddFlashcardScreen extends StatelessWidget {
  final TextEditingController questionController = TextEditingController();
  final TextEditingController answerController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Colors.blue,
        title: Text('Add Flashcard',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),),
      ),
      body: Center(
        child: Container(
          height: 300,
          width: 300,
           
          color: const Color.fromARGB(255, 202, 229, 242),
          child: Padding(
            padding: EdgeInsets.all(16.0),
            child: Column(
              children: [
                TextField(
                  
                  controller: questionController,
                  
                  decoration: InputDecoration(labelText: 'Question'),
                ),
                TextField(
                  controller: answerController,
                  decoration: InputDecoration(labelText: 'Answer'),
                ),
                SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    final question = questionController.text;
                    final answer = answerController.text;
                    if (question.isNotEmpty && answer.isNotEmpty) {
                      Navigator.pop(context, Flashcard(question: question, answer: answer));
                    }
                  },
                  child: Text('Save'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// lib/models/flashcard.dart
class Flashcard {
  final String question;
  final String answer;

  Flashcard({required this.question, required this.answer});
}

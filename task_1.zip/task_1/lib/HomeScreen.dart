

import 'package:flutter/material.dart';
import 'package:task_1/Quizscreen.dart';
import 'package:task_1/flashcardscreen.dart';

import '../models/flashcard.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Flashcard> flashcards = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        centerTitle: true,
        title: Text('Flashcard Quiz App',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold)),
      ),
      body: Center(
        child: Container(
          height: 200,
          width: 200,
          color: Color.fromARGB(255, 176, 220, 243),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white, backgroundColor: const Color.fromARGB(255, 149, 194, 230), // Text color
              ),                onPressed: () async {
                  final result = await Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AddFlashcardScreen()),
                  );
                  if (result != null) {
                    setState(() {
                      flashcards.add(result);
                    });
                  }
                },
                child: Text('Add Flashcard',style: TextStyle(color: Color.fromARGB(255, 63, 2, 247),fontWeight: FontWeight.bold),),
              ),
              SizedBox(height: 20,),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                foregroundColor: Colors.white, backgroundColor: Color.fromARGB(255, 149, 194, 230), // Text color
              ), 
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => QuizScreen(flashcards: flashcards)),
                  );
                },
                child: Text('Start Quiz',style: TextStyle(color: Color.fromARGB(255, 63, 2, 247),fontWeight: FontWeight.bold),),
              ),
            ],
          ),
        ),
      ),
    );
  }
}



